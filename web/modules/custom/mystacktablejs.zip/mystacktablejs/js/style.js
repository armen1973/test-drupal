(function($, Drupal, drupalSettings) {
    $('#card-table').cardtable();
}) (jQuery, Drupal, drupalSettings);
